# Revamped Configuration

## Keep
- Gitsigns
- Telescope
