---
--- Keymaps
---

local k = vim.keymap.set
local opts = { noremap = true, silent = true }
-- Remap for dealing with word wrap
k('n', 'k', "v:count == 0 ? 'gk' : 'k'", { expr = true, silent = true })
k('n', 'j', "v:count == 0 ? 'gj' : 'j'", { expr = true, silent = true })

-- Basics
k('n', '<Esc>', '<cmd>nohlsearch<CR>')
k('i', 'jk', '<Esc>', opts)
k('i', 'JK', '<Esc>', opts)

k('n', '<C-h>', '<C-w><C-h>', { desc = 'Move focus to the left window' })
k('n', '<C-l>', '<C-w><C-l>', { desc = 'Move focus to the right window' })
k('n', '<C-j>', '<C-w><C-j>', { desc = 'Move focus to the lower window' })
k('n', '<C-k>', '<C-w><C-k>', { desc = 'Move focus to the upper window' })

k('v', '<', '<gv', opts)
k('v', '>', '>gv', opts)

-- Keep paste buffer clean
k('x', 'p', [["_dP]])


-- Diagnostics
k('n', '[d', vim.diagnostic.goto_prev, { desc = 'Go to previous [D]iagnostic message' })
k('n', ']d', vim.diagnostic.goto_next, { desc = 'Go to next [D]iagnostic message' })
k('n', '<leader>e', vim.diagnostic.open_float, { desc = 'Show diagnostic [E]rror messages' })
k('n', '<leader>q', vim.diagnostic.setloclist, { desc = 'Open diagnostic [Q]uickfix list' })


-- k('v', '<A-j>', ":m '>+1<CR>gv=gv", { opts, desc = 'Move Block Down' })
-- k('v', '<A-k>', ":m '<-2<CR>gv=gv", { opts, desc = 'Move Block Up' })


vim.api.nvim_create_autocmd('TextYankPost', {
  desc = 'Highlight when yanking (copying) text',
  group = vim.api.nvim_create_augroup('kickstart-highlight-yank', { clear = true }),
  callback = function()
    vim.highlight.on_yank()
  end,
})


