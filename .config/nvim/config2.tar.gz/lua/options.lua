local o = vim.opt

vim.g.mapleader = ' '
vim.g.maplocalleader = ' '
vim.g.have_nerd_font = true

-- sync clipboard between OS and Neovim.
--  schedule the setting after `UiEnter` because it can increase startup-time.
--  remove this option if you want your OS clipboard to remain independent.
vim.schedule(function()
  o.clipboard = 'unnamedplus'
end)
-- o.clipboard = 'unnamedplus'

-- sidebar stuff
o.number = true
o.relativenumber = true
o.signcolumn = 'yes'

-- tab stuff
o.expandtab = true
o.tabstop = 4
o.shiftwidth = 4

-- visual block cool behavior
o.virtualedit = 'block'
-- "true color support" for terminals like kitty
o.termguicolors = true

-- self-explanatory
o.mouse = 'a'
o.timeoutlen = 125 -- time to wait for a mapped sequence to complete (in milliseconds)
o.hlsearch = true
o.inccommand = 'split'  -- Preview substitutions live, as you type
o.showmode = false
o.splitright = true
o.splitbelow = true
-- enable break indent
o.breakindent = true

-- save undo history
o.undofile = true

-- case-insensitive searching UNLESS \C or one or more capital letters in the search term
o.ignorecase = true
o.smartcase = true
o.updatetime = 250

-- differentiate tab characters and stuff
-- o.list = true
-- o.listchars = { tab = '» ', trail = '·', nbsp = '␣' }

-- Other QOL stuff
o.cursorline = true     -- see what line you're on
o.scrolloff = 999       -- always centered when jumping
o.smartindent = true
o.swapfile = false
-- If this many milliseconds nothing is typed the swap file will be written to disk
o.updatetime = 100 -- faster completion (4000ms default)
o.numberwidth = 2 -- set number column width to 2 {default 4}




